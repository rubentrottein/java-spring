package com.example.firstProjectSB.service;

import org.springframework.stereotype.Service;

@Service
public class FirstService {

	public String addTruc(String s) {
		return s + "truc";
	}
}
